---
layout: post
title: 用 Travis CI 免费自动构建和部署 GitBook
categories: GitHub
description: 手动构建和发布 GitBook 电子书到 GitHub Pages 繁琐又费时，利用 Travsi CI 来解放自己的时间和双手。
keywords: gitbook, travis-ci
---


