---
layout: mindmap
title: Skill Tree
cate1: Mindmap
cate2:
description: 个人技能树思维导图
keywords: 技能树, 思维导图, mindmap, 脑图
---

```mindmap
# 技能树
## Java 后端开发
## Android 开发
## Windows 开发
## 通用技能
### 操作系统
#### Windows
#### Linux
#### macOS
### 编辑器
#### Vim
#### Visual Studio Code
### 标记语言
#### Markdown
### 版本控制
#### Git
#### SVN
```
