---
layout: wiki
title: Badminton
cate1: Hobbies
cate2: 
description: 羽毛球学习资源整理。
keywords: 羽毛球
---

## 视频

李在福系列：

1. [追球（基础系列）](https://www.bilibili.com/video/BV1Yx411W7nJ)
2. [双打](https://www.bilibili.com/video/BV1Yx411W7sS)
3. [混双](https://www.bilibili.com/video/BV1Zx411W7AH)
4. [杀球技巧](https://www.bilibili.com/video/BV1Zx411W7FC)
5. [网前扑球](https://www.bilibili.com/video/BV1hx411V7we)
6. [反手后场高球](https://www.bilibili.com/video/BV1hx411V7cZ)
7. [步伐](https://www.bilibili.com/video/BV1hx411V7cK)
8. [步伐训练](https://www.bilibili.com/video/BV1hx411V7cL)
9. [论球](https://www.bilibili.com/video/BV1hx411V7uY)

## 公众号

* 和蔡赟聊羽毛球

  微信号：caiyunliaoyumaoqiu

## 动作要领笔记

### 双打反手发网前球

1. 持球手大拇指和食指捏住羽毛，其余三指自然伸直；
2. 主要是手腕发力，大小臂都保持稳定；
