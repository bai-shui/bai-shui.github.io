---
layout: wiki
title: WebView
cate1: Android
cate2: View
description: WebView
keywords: Android
---

## WebViewClient 与 WebChromeClient

WebViewClient 主要涉及与页面加载相关的一些事件回调和处理，我理解应该更多是与 WebView 背后的运行机制的交互。

WebChromeClient 主要是标题、图标、加载进度、JS 弹窗、文件选择和一些视图显隐的控制，我理解主要是与 WebView 界面显示部分的交互。
