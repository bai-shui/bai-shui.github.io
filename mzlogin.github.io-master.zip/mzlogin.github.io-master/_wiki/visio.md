---
layout: wiki
title: Visio
cate1: Tools
cate2:
description: Windows 下最好用的流程图软件。
keywords: Visio
---

## 小问题记录

### 连接线箭头

如果在 Visio 2013/2016 里画流程图，发现连接线没有箭头，检查一下「设计」菜单里是否将主题设置成了「无主题」，如果是，取消掉就好了。

### 鼠标悬停提示

把鼠标悬停在图形上四周应该有几个小三角提示，如果没有，检查「视图」里是否勾选了「自动连接」，如果没有，勾选上。

### 调整导出 PNG 大小

导出 PNG 时，填好保存位置和文件名之后，会弹出一个「PNG 输出选项」，在其中调整大小即可。

![](/images/wiki/visio-png-size.png)
