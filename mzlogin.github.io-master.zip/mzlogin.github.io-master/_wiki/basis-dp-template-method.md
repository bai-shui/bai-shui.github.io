---
layout: wiki
title: 模板方法模式
cate1: Basis
cate2: 设计模式
description: 模板方法模式
keywords: Basis
---

## 定义

在父类中实现一个算法不变的部分，并将可变的行为留给子类来实现。

## Android 中的应用

AsyncTask、Activity、Fragment、Service 等的生命周期方法。
